case $1 in
    mysql)
        service mysql stop
        ;;
esac