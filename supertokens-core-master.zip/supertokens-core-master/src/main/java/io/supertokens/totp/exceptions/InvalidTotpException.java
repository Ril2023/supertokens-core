package io.supertokens.totp.exceptions;

public class InvalidTotpException extends Exception {

}
