package io.supertokens.ee.test;

class TestingProcessManagerException extends Exception {

    private static final long serialVersionUID = 1L;

    public TestingProcessManagerException(String message) {
        super(message);
    }

}
