---
name: 📚 Documentation
about: Report an issue related to documentation
labels: 'documentation'
---

## 📚 Documentation

Please open an issue https://github.com/supertokens/docs/issues instead.

