---
name: 🚀 Feature
about: Submit a proposal/request for a new feature
labels: 'enhancement'
---

## 🚀 Feature

(A clear and concise description of what the feature is.)

## Implementation details

(Please outline any details about how this feature would e implemented. If you don't know, you can just skip this section.)
